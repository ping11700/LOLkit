﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QiHe.Yaml.Grammar
{
    public partial class TagDirective : Directive
    {
        public TagHandle Handle;

        public TagPrefix Prefix;

    }
}
