﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QiHe.Yaml.Grammar
{
    public partial class TagPrefix
    {
        public List<char> Prefix = new List<char>();

    }
}
