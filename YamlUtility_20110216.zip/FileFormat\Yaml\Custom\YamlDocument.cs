﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QiHe.Yaml.Grammar
{
	public partial class YamlDocument
	{
        public Dictionary<string, DataItem> AnchoredItems = new Dictionary<string, DataItem>();

	}
}
