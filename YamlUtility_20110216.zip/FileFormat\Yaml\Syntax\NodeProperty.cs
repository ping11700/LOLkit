﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QiHe.Yaml.Grammar
{
    public partial class NodeProperty
    {
        public Tag Tag;

        public string Anchor;

    }
}
